using Xunit;

namespace WebApplication1.Tests;

public class XUnitTestClass
{
    [Fact]
    public void Test1()
    {
        Console.WriteLine("Hello");
    }
}