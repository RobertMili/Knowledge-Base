namespace WebApplication1.Dto;

public class SuperHeroCreateDto
{
    public string Name { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Place { get; set; }
}